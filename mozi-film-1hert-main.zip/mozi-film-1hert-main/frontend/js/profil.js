// js/profil.js

import { getUserBookingsAPI, deleteBookingAPI } from './api.js';

document.addEventListener('DOMContentLoaded', function() {
    const navLoggedOut = document.getElementById('navLoggedOut');
    const navLoggedIn = document.getElementById('navLoggedIn');
    const logoutBtnProfile = document.getElementById('logoutBtnProfile'); 
    const welcomeUserSpan = document.getElementById('welcomeUser');

    const profileUsernameSpan = document.getElementById('profileUsername');
    const profileEmailSpan = document.getElementById('profileEmail');
    const userBookingsContainer = document.getElementById('userBookingsContainer');

    function getAuthToken() {
        return sessionStorage.getItem('authToken');
    }

    async function loadAndDisplayUserBookings() {
        const token = getAuthToken();
        if (!token || !userBookingsContainer) return;

        userBookingsContainer.innerHTML = '<p>Foglalások betöltése...</p>';

        try {
            const bookings = await getUserBookingsAPI(token);

            if (bookings.length === 0) {
                userBookingsContainer.innerHTML = '<p>Nincsenek aktív foglalásaid.</p>';
                return;
            }

            userBookingsContainer.innerHTML = ''; // Konténer ürítése
            bookings.forEach(booking => {
                const screeningTime = new Date(booking.Screening.time).toLocaleString('hu-HU');
                const card = document.createElement('div');
                card.className = 'booking-card';
                card.dataset.bookingId = booking.id;
                
                card.innerHTML = `
                    <div class="booking-card-info">
                        <p><strong>Film:</strong> ${booking.Screening.Movie.title}</p>
                        <p><strong>Vetítés:</strong> ${screeningTime}</p>
                        <p><strong>Hely:</strong> ${booking.seat}</p>
                    </div>
                    <div class="booking-card-actions">
                        <button class="delete-booking-btn" data-booking-id="${booking.id}">Törlés</button>
                    </div>
                `;
                userBookingsContainer.appendChild(card);
            });

        } catch (error) {
            userBookingsContainer.innerHTML = `<p style="color: #e50914;">Hiba a foglalások betöltésekor: ${error.message}</p>`;
        }
    }

    if (userBookingsContainer) {
        userBookingsContainer.addEventListener('click', async (e) => {
            if (e.target.classList.contains('delete-booking-btn')) {
                const bookingId = e.target.dataset.bookingId;
                if (!confirm('Biztosan törölni szeretnéd ezt a foglalást?')) return;
                
                const token = getAuthToken();
                try {
                    await deleteBookingAPI(bookingId, token);
                    alert('Foglalás sikeresen törölve.');
                    loadAndDisplayUserBookings(); 
                } catch (error) {
                    alert(`Hiba a törlés során: ${error.message}`);
                }
            }
        });
    }

    function updateProfilePageUI(isLoggedIn, userData = null) {
        if (navLoggedOut && navLoggedIn) {
            if (isLoggedIn) {
                navLoggedOut.style.display = 'none';
                navLoggedIn.style.display = 'flex'; 

                if (welcomeUserSpan && userData) {
                    welcomeUserSpan.textContent = `Üdv, ${userData.username || userData.emailAddress.split('@')[0]}!`;
                }
                if (profileUsernameSpan && userData) profileUsernameSpan.textContent = userData.username || "Nincs megadva";
                if (profileEmailSpan && userData) profileEmailSpan.textContent = userData.emailAddress || "Nincs megadva";

            } else {
                alert('A profil megtekintéséhez be kell jelentkeznie.');
                window.location.href = 'index.html'; 
            }
        } else {
            if (!isLoggedIn) {
                alert('A profil megtekintéséhez be kell jelentkeznie.');
                window.location.href = 'index.html';
            }
        }
    }

    function handleLogoutFromProfile() {
        sessionStorage.removeItem('isLoggedIn');
        sessionStorage.removeItem('userData');
        sessionStorage.removeItem('authToken');
        alert('Sikeresen kijelentkezett.');
        window.location.href = 'index.html'; 
    }

    if (logoutBtnProfile) {
        logoutBtnProfile.addEventListener('click', function(event) {
            event.preventDefault();
            handleLogoutFromProfile();
        });
    }


    const isLoggedInOnLoad = sessionStorage.getItem('isLoggedIn') === 'true';
    let storedUserData = null;
    if (isLoggedInOnLoad) {
        try {
            storedUserData = JSON.parse(sessionStorage.getItem('userData'));
            loadAndDisplayUserBookings(); 
             loadUserBookingCount(storedUserData.id);
        } catch (e) {
            console.error("Hiba a felhasználói adatok sessionStorage-ből való olvasásakor:", e);
            handleLogoutFromProfile();
            return; 
        }
    }
    
    updateProfilePageUI(isLoggedInOnLoad, storedUserData);

    let inactivityTimer;
    const INACTIVITY_TIMEOUT_MS = 10 * 60 * 1000; // 10 perc

    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
            if (sessionStorage.getItem('isLoggedIn') === 'true') {
                alert('Az inaktivitás miatt automatikusan kijelentkeztettünk.');
                handleLogoutFromProfile(); 
            }
        }, INACTIVITY_TIMEOUT_MS);
    }

    function startInactivityTimer() {
        if (sessionStorage.getItem('isLoggedIn') === 'true') {
            ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart'].forEach(event => {
                document.addEventListener(event, resetInactivityTimer, { passive: true });
            });
            resetInactivityTimer();
        }
    }

    if (isLoggedInOnLoad) {
        startInactivityTimer(); 
    }




    async function loadUserBookingCount(userId) {
  try {
    const res = await fetch(`/api/users/${userId}/stats`);
    if (!res.ok) throw new Error('Nem sikerült betölteni a foglalások számát');
    const stats = await res.json();

    const bookingCountElem = document.getElementById('bookingCount') || document.getElementById('profileBookingCount');
    if (bookingCountElem) {
      bookingCountElem.textContent = stats.totalBookings; // <-- Itt a javítás
    }
  } catch (error) {
    console.error('Foglalásszám betöltési hiba:', error);
  }
}


});
