// js/main.js

import {
    checkUser,
    createUser,
    getMovies,
    createMovieAPI,
    updateMovieAPI,
    deleteMovieAPI,
    createScreeningAPI,
    getScreenings,
    getScreeningsByMovieAPI,
    getScreeningsByDateAPI,
    getScreeningDetailsAPI,
    createBookingAPI, // ÚJ import a foglaláshoz
} from './api.js';

document.addEventListener('DOMContentLoaded', function () {
    
    // --- DOM Elemek Referenciáinak Gyűjtése ---
    const screeningDetailsModal = document.getElementById('screeningDetailsModal');
    const screeningDetailsModalCloseBtn = document.getElementById('screeningDetailsModalCloseBtn');
    const screeningDetailsContent = document.getElementById('screeningDetailsContent');
    const authModal = document.getElementById('authModal');
    const modalCloseBtn = document.getElementById('modalCloseBtn');
    const dateFilterInput = document.getElementById('dateFilterInput');
    const clearDateFilterBtn = document.getElementById('clearDateFilterBtn');

    // ÚJ: Foglalási űrlap elemei
    const bookingFormContainer = document.getElementById('bookingFormContainer');
    const bookingFormActual = document.getElementById('bookingFormActual');
    const confirmBookingBtn = document.getElementById('confirmBookingBtn');
    const seatInput = document.getElementById('seatInput');

    const navLoggedOut = document.getElementById('navLoggedOut');
    const navLoggedIn = document.getElementById('navLoggedIn');
    const logoutBtn = document.getElementById('logoutBtn');
    const welcomeUserSpan = document.getElementById('welcomeUser');
    let loginBtnHeader = null;
    let registerBtnHeader = null;

    if (navLoggedOut) {
        loginBtnHeader = navLoggedOut.querySelector('a.login-btn');
        registerBtnHeader = navLoggedOut.querySelector('a.register-btn');
    } else {
        loginBtnHeader = document.querySelector('header nav a.login-btn');
        registerBtnHeader = document.querySelector('header nav a.register-btn');
    }

    const loginFormContainer = document.getElementById('loginFormContainer');
    const registerFormContainer = document.getElementById('registerFormContainer');
    const showRegisterFormLink = document.getElementById('showRegisterFormLink');
    const showLoginFormLink = document.getElementById('showLoginFormLink');

    const loginFormActual = document.getElementById('loginFormActual');
    const registerFormActual = document.getElementById('registerFormActual');
    
    let inactivityTimer;
    const INACTIVITY_TIMEOUT_MS = 10 * 60 * 1000;

    const searchInput = document.getElementById('searchInput');
    const searchButton = document.getElementById('searchButton');
    const clearSearchButton = document.getElementById('clearSearchButton');

    const movieGrid = document.querySelector('.movie-grid');
    const addMovieBtnContainer = document.getElementById('addMovieBtnContainer');
    const addMovieBtn = document.getElementById('addMovieBtn');

    const screeningsGrid = document.querySelector('.screenings-grid');
    const addScreeningBtnContainer = document.getElementById('addScreeningBtnContainer');
    const addScreeningBtn = document.getElementById('addScreeningBtn');

    const movieFormModal = document.getElementById('movieFormModal');
    const movieFormModalCloseBtn = document.getElementById('movieFormModalCloseBtn');
    const movieFormActual = document.getElementById('movieFormActual');
    const movieFormTitle = document.getElementById('movieFormTitle');
    const editMovieIdInput = document.getElementById('editMovieId');
    const movieTitleInput = document.getElementById('movieTitle');
    const movieDescriptionInput = document.getElementById('movieDescription');
    const movieYearInput = document.getElementById('movieYear');
    const movieImgInput = document.getElementById('movieImg');
    const saveMovieBtn = document.getElementById('saveMovieBtn');

    const screeningFormModal = document.getElementById('screeningFormModal');
    const screeningFormModalCloseBtn = document.getElementById('screeningFormModalCloseBtn');
    const screeningFormActual = document.getElementById('screeningFormActual');
    const screeningFormTitle = document.getElementById('screeningFormTitle');
    const editScreeningIdInput = document.getElementById('editScreeningId'); 
    const screeningRoomInput = document.getElementById('screeningRoom');
    const screeningTimeInput = document.getElementById('screeningTime');
    const saveScreeningBtn = document.getElementById('saveScreeningBtn');
    const movieFilterSelect = document.getElementById('movieFilterSelect');
    const screeningMovieIdSelect = document.getElementById('screeningMovieIdSelect');

    let currentEditingMovieId = null;
    let currentEditingScreeningId = null;
    let allMoviesCache = [];

    // --- Segédfüggvények (Helpers) ---
    function getAuthToken() {
        return sessionStorage.getItem('authToken');
    }

    function getUserData() {
        const userDataString = sessionStorage.getItem('userData');
        return userDataString ? JSON.parse(userDataString) : null;
    }

    function isAdminUser() {
        const userData = getUserData();
        return userData && userData.isAdmin === true;
    }

    function openModal() {
        if (authModal) authModal.style.display = 'flex';
    }

    function closeModal() {
        if (authModal) {
            authModal.style.display = 'none';
            if (loginFormActual) loginFormActual.reset();
            if (registerFormActual) registerFormActual.reset();
        }
    }

    function showLoginForm() {
        if (loginFormContainer && registerFormContainer) {
            loginFormContainer.classList.remove('form-hidden');
            registerFormContainer.classList.add('form-hidden');
        }
    }

    function showRegisterForm() {
        if (loginFormContainer && registerFormContainer) {
            loginFormContainer.classList.add('form-hidden');
            registerFormContainer.classList.remove('form-hidden');
        }
    }

    function openMovieFormModal(mode = 'create', movie = null) {
        if (!movieFormModal) return;
        currentEditingMovieId = null;
        movieFormActual.reset();

        if (mode === 'edit' && movie) {
            movieFormTitle.textContent = 'Film szerkesztése';
            editMovieIdInput.value = movie.id;
            movieTitleInput.value = movie.title || '';
            movieDescriptionInput.value = movie.description || '';
            movieYearInput.value = movie.year || '';
            movieImgInput.value = movie.img || '';
            currentEditingMovieId = movie.id;
        } else {
            movieFormTitle.textContent = 'Új film hozzáadása';
            editMovieIdInput.value = '';
        }
        movieFormModal.style.display = 'flex';
    }

    function populateMovieSelects() {
        if (!movieFilterSelect || !screeningMovieIdSelect || allMoviesCache.length === 0) return;

        movieFilterSelect.innerHTML = '<option value="all">Összes film</option>';
        screeningMovieIdSelect.innerHTML = '<option value="" disabled selected>Válassz filmet...</option>';

        allMoviesCache.forEach(movie => {
            const option = document.createElement('option');
            option.value = movie.id;
            option.textContent = movie.title;
            movieFilterSelect.appendChild(option.cloneNode(true));
            screeningMovieIdSelect.appendChild(option.cloneNode(true));
        });
    }

    function openScreeningFormModal(mode = 'create', screening = null) {
        if (!screeningFormModal) return;
        currentEditingScreeningId = null;
        screeningFormActual.reset();

        if (mode === 'edit' && screening) {
            screeningFormTitle.textContent = 'Vetítés szerkesztése';
            if (editScreeningIdInput) editScreeningIdInput.value = screening.id;
            if (screeningRoomInput) screeningRoomInput.value = screening.room || '';
            if (screeningTimeInput && screening.time) {
                const date = new Date(screening.time);
                screeningTimeInput.value = date.toISOString().slice(0, 16);
            }
            currentEditingScreeningId = screening.id;
        } else {
            if (screeningFormTitle) screeningFormTitle.textContent = 'Új vetítés hozzáadása';
            if (editScreeningIdInput) editScreeningIdInput.value = '';
        }
        screeningFormModal.style.display = 'flex';
    }

    function closeMovieFormModal() {
        if (movieFormModal) {
            movieFormModal.style.display = 'none';
            movieFormActual.reset();
            currentEditingMovieId = null;
        }
    }

    function closeScreeningFormModal() {
        if (screeningFormModal) {
            screeningFormModal.style.display = 'none';
            screeningFormActual.reset();
            currentEditingScreeningId = null;
        }
    }

    function updateLoginUI(isLoggedIn, userData = null) {
        if (navLoggedOut && navLoggedIn && welcomeUserSpan) {
            if (isLoggedIn) {
                navLoggedOut.style.display = 'none';
                navLoggedIn.style.display = 'flex';
                welcomeUserSpan.textContent = `Üdv, ${userData?.username || userData?.emailAddress?.split('@')[0] || ''}!`;
            } else {
                navLoggedOut.style.display = 'flex';
                navLoggedIn.style.display = 'none';
                welcomeUserSpan.textContent = '';
            }
        }
        if (addMovieBtnContainer) addMovieBtnContainer.style.display = isAdminUser() ? 'block' : 'none';
        if (addScreeningBtnContainer) addScreeningBtnContainer.style.display = isAdminUser() ? 'block' : 'none';
        if (movieGrid) loadAndDisplayMovies();
        if (screeningsGrid) loadAndDisplayScreenings();
    }

    function handleLoginSuccess(loginResponse) {
        sessionStorage.setItem('isLoggedIn', 'true');
        sessionStorage.setItem('userData', JSON.stringify(loginResponse.user));
        sessionStorage.setItem('authToken', loginResponse.token);
        updateLoginUI(true, loginResponse.user);
        closeModal();
        startInactivityTimer();
        alert('Sikeres bejelentkezés!');
    }

    function handleLogout(showNotification = true) {
        sessionStorage.removeItem('isLoggedIn');
        sessionStorage.removeItem('userData');
        sessionStorage.removeItem('authToken');
        allMoviesCache = [];
        updateLoginUI(false);
        clearTimeout(inactivityTimer);
        if (showNotification) alert('Sikeresen kijelentkezett.');
        if (window.location.pathname.includes('profil.html')) window.location.href = 'index.html';
    }

    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        inactivityTimer = setTimeout(() => {
            if (sessionStorage.getItem('isLoggedIn') === 'true') {
                alert('Az inaktivitás miatt automatikusan kijelentkeztettünk.');
                handleLogout(false);
            }
        }, INACTIVITY_TIMEOUT_MS);
    }

    function startInactivityTimer() {
        if (sessionStorage.getItem('isLoggedIn') === 'true') {
            ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart'].forEach(event => {
                document.addEventListener(event, resetInactivityTimer, { passive: true });
            });
            resetInactivityTimer();
        }
    }

    function displayMovies(moviesToDisplay) {
        if (!movieGrid) return;
        movieGrid.innerHTML = '';

        if (!moviesToDisplay || moviesToDisplay.length === 0) {
            const searchTerm = searchInput ? searchInput.value.trim() : '';
            movieGrid.innerHTML = `<p class="info-message">${searchTerm !== '' ? `Nincs találat a keresésre: "${searchTerm}"` : 'Jelenleg nincsenek elérhető filmek.'}</p>`;
            return;
        }

        const admin = isAdminUser();
        moviesToDisplay.forEach(movie => {
            const movieCard = document.createElement('div');
            movieCard.className = 'movie-card';
            movieCard.dataset.movieId = movie.id;
            movieCard.dataset.title = movie.title.toLowerCase();

            movieCard.innerHTML = `
                <img src="${movie.img || 'https://via.placeholder.com/300x450.png?text=Filmplak%C3%A1t'}" alt="${movie.title || "Filmplakát"}">
                <div class="movie-info">
                    <h3>${movie.title || "Film Címe"}</h3>
                    <p class="year">Év: ${movie.year || 'Ismeretlen'}</p>
                    <p class="description">${movie.description ? (movie.description.length > 100 ? movie.description.substring(0, 97) + '...' : movie.description) : "Nincs elérhető leírás."}</p>
                    <a href="#" class="cta-button">Részletek és Jegyvásárlás</a>
                    ${admin ? `
                        <div class="admin-movie-actions">
                            <button class="update-movie-btn admin-action-btn" data-movie-id="${movie.id}">Szerkesztés</button>
                            <button class="delete-movie-btn admin-action-btn" data-movie-id="${movie.id}">Törlés</button>
                        </div>` : ''}
                </div>`;
            movieGrid.appendChild(movieCard);
        });
    }
    



    
    function openScreeningDetailsModal(screeningData) {
    if (!screeningDetailsModal || !screeningDetailsContent) return;

    // Ellenőrizzük, hogy a Movie objektum létezik-e a biztonság kedvéért
    if (!screeningData.Movie) {
        console.error("Hiányzó filmadatok a vetítéshez:", screeningData);
        // Itt akár egy hibaüzenetet is megjeleníthetsz a felhasználónak
        screeningDetailsContent.innerHTML = `<h2 class="details-title">Hiba</h2><p>A vetítéshez tartozó filmadatok nem tölthetők be.</p>`;
        screeningDetailsModal.style.display = 'flex';
        return;
    }

    const date = new Date(screeningData.time);
    const formattedDate = date.toLocaleDateString('hu-HU', { year: 'numeric', month: 'long', day: 'numeric' });
    const formattedTime = date.toLocaleTimeString('hu-HU', { hour: '2-digit', minute: '2-digit' });

    // JAVÍTVA: screeningData.movie -> screeningData.Movie
    screeningDetailsContent.innerHTML = `
        <h2 class="details-title">${screeningData.Movie.title}</h2>
        <div class="details-grid">
            <img src="${screeningData.Movie.img || 'https://via.placeholder.com/300x450'}" alt="${screeningData.Movie.title}" class="details-img">
            <div class="details-info">
                <p><strong>Vetítés időpontja:</strong> ${formattedDate} - ${formattedTime}</p>
                <p><strong>Terem:</strong> ${screeningData.room}</p>
                <p><strong>Film éve:</strong> ${screeningData.Movie.year}</p>
                <p><strong>Leírás:</strong></p>
                <p class="details-description">${screeningData.Movie.description}</p>
                <p><small>Vetítést rögzítette: ${screeningData.adminName}</small></p>
            </div>
        </div>`;
    
    const isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true';
    if (bookingFormContainer) bookingFormContainer.style.display = isLoggedIn ? 'block' : 'none';
    if (confirmBookingBtn) confirmBookingBtn.dataset.screeningId = screeningData.id;

    screeningDetailsModal.style.display = 'flex';
}

    function closeScreeningDetailsModal() {
        if (screeningDetailsModal) {
            screeningDetailsModal.style.display = 'none';
            screeningDetailsContent.innerHTML = '<p class="loading-message">Részletek betöltése...</p>';
            if(bookingFormActual) bookingFormActual.reset();
        }
    }

    function displayScreenings(screeningsToDisplay) {
        if (!screeningsGrid) return;
        screeningsGrid.innerHTML = '';

        if (!screeningsToDisplay || screeningsToDisplay.length === 0) {
            screeningsGrid.innerHTML = '<p class="info-message">Nincsenek a szűrőfeltételnek megfelelő vetítések.</p>';
            return;
        }

        screeningsToDisplay.forEach(screening => {
            const screeningCard = document.createElement('div');
            screeningCard.className = 'screening-card';
            screeningCard.dataset.screeningId = screening.id;
            const date = new Date(screening.time);

            screeningCard.innerHTML = `
                <p class="movie-title-on-card">${screening.movie ? screening.movie.title : 'Ismeretlen film'}</p>
                <h3>Terem: ${screening.room}</h3>
                <p>Idő: ${date.toLocaleString('hu-HU')}</p>
                <p>Létrehozta: ${screening.adminName}</p>
                <button class="screening-details-btn" data-screening-id="${screening.id}">Részletek</button>
            `;
            // Admin gombok (ha kellenek a jövőben) ide jöhetnének
            screeningsGrid.appendChild(screeningCard);
        });
    }




    
    async function loadAndDisplayMovies() {
        if (!movieGrid) return;
        movieGrid.innerHTML = '<p class="loading-message">Filmek betöltése...</p>';
        if (searchInput) searchInput.value = '';
        if (clearSearchButton) clearSearchButton.style.display = 'none';

        try {
            const moviesData = await getMovies();
            allMoviesCache = moviesData;
            displayMovies(allMoviesCache);
            populateMovieSelects();
            loadTopMovies();
        } catch (error) {

            console.error("Hiba a filmek betöltésekor:", error);
            allMoviesCache = [];
            if (movieGrid) movieGrid.innerHTML = `<p class="error-message">Hiba történt a filmek betöltése közben. (${error.message})</p>`;
        }
    }

    async function loadAndDisplayScreenings() {
        if (!screeningsGrid) return;
        screeningsGrid.innerHTML = '<p class="loading-message">Vetítések betöltése...</p>';
        
        try {
            const screeningsData = await getScreenings();
            displayScreenings(screeningsData);
        } catch (error) {
            console.error("Hiba a vetítések betöltésekor:", error);
            screeningsGrid.innerHTML = `<p class="error-message">Hiba történt a vetítések betöltése közben. (${error.message})</p>`;
        }
    }

    async function refreshPageData() {
        if (!movieGrid && !screeningsGrid) return;
        if (movieGrid) movieGrid.innerHTML = '<p class="loading-message">Filmek frissítése...</p>';
        if (screeningsGrid) screeningsGrid.innerHTML = '<p class="loading-message">Vetítések frissítése...</p>';
        if (searchInput) searchInput.value = '';
        if (clearSearchButton) clearSearchButton.style.display = 'none';

        try {
            const [moviesData, screeningsData] = await Promise.all([ getMovies(), getScreenings() ]);
            allMoviesCache = moviesData;
            if (movieGrid) displayMovies(allMoviesCache);
            populateMovieSelects();
            if (screeningsGrid) displayScreenings(screeningsData);
        } catch (error) {
            console.error("Hiba az adatok közös frissítésekor:", error);
            if (movieGrid) movieGrid.innerHTML = `<p class="error-message">Hiba történt a filmek betöltése közben. (${error.message})</p>`;
            if (screeningsGrid) screeningsGrid.innerHTML = `<p class="error-message">Hiba történt a vetítések betöltése közben. (${error.message})</p>`;
        }
    }

    function handleSearch() {
        if (!searchInput || !movieGrid) return;
        const searchTerm = searchInput.value.trim().toLowerCase();
        if (clearSearchButton) clearSearchButton.style.display = searchTerm ? 'inline-block' : 'none';

        const filteredMovies = allMoviesCache.filter(movie => movie.title.toLowerCase().includes(searchTerm));
        displayMovies(filteredMovies);
    }

    // --- Eseménykezelők Regisztrálása ---

    if (loginBtnHeader) loginBtnHeader.addEventListener('click', (e) => { e.preventDefault(); showLoginForm(); openModal(); });
    if (registerBtnHeader) registerBtnHeader.addEventListener('click', (e) => { e.preventDefault(); showRegisterForm(); openModal(); });
    if (logoutBtn) logoutBtn.addEventListener('click', (e) => { e.preventDefault(); handleLogout(); });
    if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);
    if (authModal) authModal.addEventListener('click', (e) => { if (e.target === authModal) closeModal(); });
    if (movieFormModal) movieFormModal.addEventListener('click', (e) => { if (e.target === movieFormModal) closeMovieFormModal(); });
    if (screeningFormModal) screeningFormModal.addEventListener('click', (e) => { if (e.target === screeningFormModal) closeScreeningFormModal(); });
    if (movieFormModalCloseBtn) movieFormModalCloseBtn.addEventListener('click', closeMovieFormModal);
    if (screeningFormModalCloseBtn) screeningFormModalCloseBtn.addEventListener('click', closeScreeningFormModal);
    if (screeningDetailsModal) screeningDetailsModal.addEventListener('click', (e) => { if (e.target === screeningDetailsModal) closeScreeningDetailsModal(); });
    if (screeningDetailsModalCloseBtn) screeningDetailsModalCloseBtn.addEventListener('click', closeScreeningDetailsModal);

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            if (authModal?.style.display === 'flex') closeModal();
            if (movieFormModal?.style.display === 'flex') closeMovieFormModal();
            if (screeningFormModal?.style.display === 'flex') closeScreeningFormModal();
            if (screeningDetailsModal?.style.display === 'flex') closeScreeningDetailsModal();
        }
    });

    if (showRegisterFormLink) showRegisterFormLink.addEventListener('click', (e) => { e.preventDefault(); showRegisterForm(); });
    if (showLoginFormLink) showLoginFormLink.addEventListener('click', (e) => { e.preventDefault(); showLoginForm(); });

    if (loginFormActual) {
        loginFormActual.addEventListener('submit', (e) => {
            e.preventDefault();
            const emailAddress = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;
            if (!emailAddress || !password) return alert('Kérjük, adja meg az email címét és a jelszavát!');
            checkUser(emailAddress, password)
                .then(handleLoginSuccess)
                .catch(error => alert(`Hiba a bejelentkezés során: ${error.message}`));
        });
    }

    if (registerFormActual) {
        registerFormActual.addEventListener('submit', (e) => {
            e.preventDefault();
            const username = document.getElementById('registerUsername').value;
            const emailAddress = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (!username || !emailAddress || !password || !confirmPassword) return alert('Kérjük, töltse ki az összes mezőt!');
            if (password !== confirmPassword) return alert('A megadott jelszavak nem egyeznek!');

            createUser(username, password, emailAddress)
                .then(() => {
                    alert('Sikeres regisztráció! Most már bejelentkezhet.');
                    showLoginForm();
                })
                .catch(error => alert(`Hiba a regisztráció során: ${error.message}`));
        });
    }
    
    if (addMovieBtn) addMovieBtn.addEventListener('click', () => openMovieFormModal('create'));
    if (addScreeningBtn) addScreeningBtn.addEventListener('click', () => openScreeningFormModal('create'));

    if (movieFormActual) {
        movieFormActual.addEventListener('submit', async function (e) {
            e.preventDefault();
            const token = getAuthToken();
            const userData = getUserData();
            if (!token || !userData?.isAdmin) return alert('Nincs jogosultsága ehhez a művelethez.');

            const movieData = {
                title: movieTitleInput.value,
                description: movieDescriptionInput.value,
                year: parseInt(movieYearInput.value, 10),
                img: movieImgInput.value
            };
            saveMovieBtn.disabled = true;
            saveMovieBtn.textContent = 'Mentés...';
            try {
                if (currentEditingMovieId) {
                    await updateMovieAPI(currentEditingMovieId, movieData, userData.id, token);
                    alert('Film sikeresen frissítve!');
                } else {
                    await createMovieAPI(movieData, userData.id, token);
                    alert('Film sikeresen létrehozva!');
                }
                closeMovieFormModal();
                await refreshPageData();
            } catch (error) {
                alert(`Hiba a film mentése során: ${error.message}`);
            } finally {
                saveMovieBtn.disabled = false;
                saveMovieBtn.textContent = 'Mentés';
            }
        });
    }

    if (screeningFormActual) {
        screeningFormActual.addEventListener('submit', async function (e) {
            e.preventDefault();
            const token = getAuthToken();
            const userData = getUserData();
            if (!token || !userData?.isAdmin) return alert('Nincs jogosultsága ehhez a művelethez.');

            const screeningData = {
                movieId: screeningMovieIdSelect.value,
                room: screeningRoomInput.value,
                time: screeningTimeInput.value
            };
            if (!screeningData.movieId) return alert('Kérjük, válasszon filmet!');
            saveScreeningBtn.disabled = true;
            saveScreeningBtn.textContent = 'Mentés...';
            try {
                // Frissítés még nincs implementálva
                await createScreeningAPI(screeningData, userData.id, token);
                alert('Vetítés sikeresen létrehozva!');
                closeScreeningFormModal();
                await loadAndDisplayScreenings();
            } catch (error) {
                alert(`Hiba a vetítés mentése során: ${error.message}`);
            } finally {
                saveScreeningBtn.disabled = false;
                saveScreeningBtn.textContent = 'Mentés';
            }
        });
    }

    // ÚJ: Foglalás űrlap elküldése
    if (bookingFormActual) {
        bookingFormActual.addEventListener('submit', async (e) => {
            e.preventDefault();
            const screeningId = confirmBookingBtn.dataset.screeningId;
            const seat = seatInput.value.trim();
            const token = getAuthToken();

            if (!seat) return alert('Kérjük, adja meg a lefoglalni kívánt széket!');
            if (!token) return alert('A foglaláshoz be kell jelentkeznie!');
            
            confirmBookingBtn.disabled = true;
            confirmBookingBtn.textContent = 'Foglalás...';

            try {
                await createBookingAPI(screeningId, seat, token);
                alert(`Sikeres foglalás a(z) ${seat} helyre! A részleteket megtekintheti a profiljánál.`);
                closeScreeningDetailsModal();
            } catch (error) {
                alert(`Hiba a foglalás során: ${error.message}`);
            } finally {
                confirmBookingBtn.disabled = false;
                confirmBookingBtn.textContent = 'Hely lefoglalása';
            }
        });
    }

    if (screeningsGrid) {
        screeningsGrid.addEventListener('click', async (e) => {
            const detailsButton = e.target.closest('.screening-details-btn');
            if (detailsButton) {
                const screeningId = detailsButton.dataset.screeningId;
                try {
                    screeningDetailsModal.style.display = 'flex';
                    const screeningDetails = await getScreeningDetailsAPI(screeningId);
                    openScreeningDetailsModal(screeningDetails);
                } catch (error) {
                    alert(`Hiba a részletek betöltésekor: ${error.message}`);
                    closeScreeningDetailsModal();
                }
            }
        });
    }

    if (movieGrid) {
        movieGrid.addEventListener('click', async function (e) {
            const target = e.target;
            const movieCard = target.closest('.movie-card');
            const movieTitle = movieCard?.querySelector('h3')?.textContent || "Ismeretlen film";

            if (target.closest('.cta-button')) {
                e.preventDefault();
                alert(`"${movieTitle}" - A jegyvásárláshoz kérjük, válasszon egy vetítést az alábbi listából, majd kattintson a "Részletek" gombra.`);
            }
            else if (target.closest('.update-movie-btn')) {
                const movieId = target.closest('.update-movie-btn').dataset.movieId;
                const movieToEdit = allMoviesCache.find(movie => movie.id.toString() === movieId);
                if (movieToEdit) openMovieFormModal('edit', movieToEdit);
            }
            else if (target.closest('.delete-movie-btn')) {
                const movieId = target.closest('.delete-movie-btn').dataset.movieId;
                if (confirm(`Biztosan törölni szeretnéd a(z) "${movieTitle}" című filmet és az összes hozzá tartozó vetítést?`)) {
                    const token = getAuthToken();
                    const userData = getUserData();
                    if (!token || !userData?.isAdmin) return alert('Nincs jogosultsága ehhez a művelethez.');
                    try {
                        await deleteMovieAPI(movieId, userData.id, token);
                        alert('Film sikeresen törölve!');
                        await refreshPageData();
                    } catch (error) {
                        alert(`Hiba a film törlése során: ${error.message}`);
                    }
                }
            }
        });
    }

    if (searchButton && searchInput) {
        searchButton.addEventListener('click', handleSearch);
        searchInput.addEventListener('input', handleSearch);
        searchInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') { e.preventDefault(); handleSearch();} });
    }

    if (clearSearchButton && searchInput) {
        clearSearchButton.addEventListener('click', () => {
            searchInput.value = '';
            handleSearch();
        });
    }

    if (movieFilterSelect) {
        movieFilterSelect.addEventListener('change', async (event) => {
            const movieId = event.target.value;
            screeningsGrid.innerHTML = '<p class="loading-message">Vetítések frissítése...</p>';
            if (dateFilterInput) dateFilterInput.value = '';
            if (clearDateFilterBtn) clearDateFilterBtn.style.display = 'none';
            try {
                const filteredScreenings = movieId === 'all' ? await getScreenings() : await getScreeningsByMovieAPI(movieId);
                displayScreenings(filteredScreenings);
            } catch (error) {
                console.error('Hiba a vetítések szűrésekor:', error);
                screeningsGrid.innerHTML = `<p class="error-message">Hiba történt a vetítések frissítése közben. (${error.message})</p>`;
            }
        });
    }

    if (dateFilterInput) {
        dateFilterInput.addEventListener('change', async (event) => {
            const selectedDate = event.target.value;
            if (!selectedDate) return;
            screeningsGrid.innerHTML = '<p class="loading-message">Vetítések frissítése...</p>';
            if (movieFilterSelect) movieFilterSelect.value = 'all';
            if (clearDateFilterBtn) clearDateFilterBtn.style.display = 'inline-block';
            try {
                const filteredScreenings = await getScreeningsByDateAPI(selectedDate);
                displayScreenings(filteredScreenings);
            } catch (error) {
                console.error('Hiba a vetítések dátum szerinti szűrésekor:', error);
                screeningsGrid.innerHTML = `<p class="error-message">Hiba történt a vetítések frissítése közben. (${error.message})</p>`;
            }
        });
    }

    if (clearDateFilterBtn) {
        clearDateFilterBtn.addEventListener('click', async () => {
            dateFilterInput.value = '';
            clearDateFilterBtn.style.display = 'none';
            await loadAndDisplayScreenings();
        });
    }

    // --- Oldal Betöltődésekor Futtatandó Kód (Inicializálás) ---
    const isLoggedInOnLoad = sessionStorage.getItem('isLoggedIn') === 'true';
    if (isLoggedInOnLoad) {
        const storedUserData = getUserData();
        updateLoginUI(true, storedUserData);
        startInactivityTimer();
    } else {
        updateLoginUI(false);
    }
    refreshPageData();






    async function loadTopMovies() {
 try {
const res = await fetch('/api/movies/top');
        if (!res.ok) throw new Error('Hálózati hiba: ' + res.status);
        const data = await res.json();

        const topList = document.getElementById('topMoviesList');
        if (!topList) return;

        topList.innerHTML = '';

        data.forEach(movie => {
            const li = document.createElement('li');
            li.textContent = `${movie.title} – ${movie.totalBookings} foglalás`;
            topList.appendChild(li);
        });
    } catch (err) {
        console.error('Hiba a top filmek lekérésekor:', err);
    }
}


});





