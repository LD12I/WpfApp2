document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('screeningIdInput');
  const button = document.getElementById('loadScreeningStatsBtn');
  const output = document.getElementById('screeningStatsOutput');

  button.addEventListener('click', async () => {
    const screeningId = input.value.trim();
    if (!screeningId || isNaN(screeningId) || parseInt(screeningId) < 1) {
      output.textContent = 'Kérlek adj meg egy érvényes vetítés ID-t.';
      return;
    }

    try {
      const res = await fetch(`/api/screenings/${screeningId}/stats`);
      if (!res.ok) throw new Error('A vetítés nem található.');

      const stats = await res.json();
      output.textContent = `Foglaltság: ${stats.bookingCount} / ${stats.totalSeats} (${stats.percentage}%)`;
    } catch (error) {
      output.textContent = `Hiba: ${error.message}`;
    }
  });
});