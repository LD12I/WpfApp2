// routes/api.js

const express = require('express');
const auth = require('../middleware/auth');
const router = express.Router();
const userController = require('../controllers/userController');
const movieController = require('../controllers/moiveController');
const screeningController = require('../controllers/screeningController');
const bookingController = require('../controllers/bookingController');


//FELHASZNÁLÓK
router.post('/users/loginCheck', userController.loginCheck);
router.post('/users/register', userController.createUser);
router.get('/users/getUser/:accountId', auth, userController.getOneUserByID);

//FILMEK (a nyilvános GET kérések kivételével mindenhez kell auth)
router.get('/movies/movies', movieController.getAllMovies);
router.get('/movies/movie-by-id/:movieId', movieController.getOneMovieByID);
router.get('/movies/movies/:title', movieController.getOneMovieByTitle);
router.post('/movies/movies', auth, movieController.createMovie);
router.put('/movies/movies/:movieId', auth, movieController.updateMovie);
router.delete('/movies/movies/:movieId', auth, movieController.deleteMovie);

//
//VETÍTÉSEK (a nyilvános GET kérések kivételével mindenhez kell auth)
//
router.get('/screenings/screenings', screeningController.getAllScreenings);
router.get('/screenings/movie/:movieId', screeningController.getScreeningsByMovieId);
router.get('/screenings/date/:date', screeningController.getScreeningsByDate);
router.get('/screenings/details/:id', screeningController.getOneScreeningByID);
router.post('/screenings/screenings', auth, screeningController.createScreening);

//
//FOGLALÁSOK (minden művelethez bejelentkezés szükséges)
//
router.post('/bookings', auth, bookingController.createBooking);
router.get('/users/me/bookings', auth, bookingController.getUserBookings);
router.delete('/bookings/:id', auth, bookingController.deleteBooking);



router.get('/screenings/:id/stats', screeningController.getScreeningStats);
router.get('/movies/top', movieController.getTopMovies);
router.get('/users/:id/stats', userController.getUserBookingStats);



module.exports = router;