// models/Screenings.js

'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Screenings extends Model {
    static associate(models) {
      // Egy vetítés egy filmhez tartozik
      Screenings.belongsTo(models.Movies, { 
          foreignKey: 'movieId',
          onDelete: 'CASCADE'
      });
      // Egy vetítéshez több foglalás tartozhat
      Screenings.hasMany(models.Booking, { foreignKey: 'screeningId' });
    }
  }
  Screenings.init({
    id: {
        type: DataTypes.INTEGER, 
        allowNull: false,       
        autoIncrement: true,     
        primaryKey: true,        
    },
    movieId: {
        type: DataTypes.INTEGER, 
        allowNull: false,
    },
    room: {
        type: DataTypes.STRING, 
        allowNull: false
    },
    time: {
        type: DataTypes.DATE, 
        allowNull: false
    },
    adminName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW 
    }
  }, {
    sequelize,
    modelName: 'Screenings',
    tableName: 'screenings',
    timestamps: false
  });
  return Screenings;
};