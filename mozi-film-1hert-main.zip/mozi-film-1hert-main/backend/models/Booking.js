// models/Booking.js

'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Booking extends Model {
    static associate(models) {
      // Egy foglalás egy felhasználóhoz tartozik
      Booking.belongsTo(models.User, { foreignKey: 'userId' });
      // Egy foglalás egy vetítéshez tartozik
      Booking.belongsTo(models.Screenings, { foreignKey: 'screeningId', onDelete: 'CASCADE' });
    }
  }
  Booking.init({
    id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    screeningId: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    seat: {
        type: DataTypes.STRING,
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    }
  }, {
    sequelize,
    modelName: 'Booking',
    tableName: 'bookings',
    timestamps: false
  });
  return Booking;
};