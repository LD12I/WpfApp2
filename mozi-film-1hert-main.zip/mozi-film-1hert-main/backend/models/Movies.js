// models/Movies.js

'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Movies extends Model {
    static associate(models) {
      // Egy filmhez több vetítés tartozhat
      Movies.hasMany(models.Screenings, { foreignKey: 'movieId' });
    }
  }
  Movies.init({
    id: {
        type: DataTypes.INTEGER, 
        allowNull: false,        
        autoIncrement: true,    
        primaryKey: true,        
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false        
    },
    description: {
        type: DataTypes.STRING, 
        allowNull: false       
    },
    year: {
        type: DataTypes.INTEGER, 
        allowNull: false         
    },
    img: {
        type: DataTypes.STRING,
        allowNull: false        
    },
    adminName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    createdAt: {
        type: DataTypes.DATE,          
        allowNull: false,
        defaultValue: DataTypes.NOW    
    }
  }, {
    sequelize,
    modelName: 'Movies',
    tableName: 'movies',
    timestamps: false
  });
  return Movies;
};