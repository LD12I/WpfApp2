// server.js

require('dotenv').config();
const express=require('express');
const apiRoutes=require('./routes/api');
const rateLimit=require('express-rate-limit');
const helmet=require('helmet');
const cors=require('cors');
const morgan=require('morgan');
// Az adatbázis és a modellek központi importja
const db = require('./models');

const port=process.env.PORT||4444;
const app=express();

// Az adatbázis szinkronizálása a modellek alapján
db.sequelize.sync().then(() => {
    console.log('\x1b[36m%s\x1b[0m','Adatbázis és modellek sikeresen szinkronizálva!');
}).catch(error => {
    console.error(`Hiba történt az adatbázis szinkronizálása közben: ${error.message}`)
});

const limiter=rateLimit({windowMs:1*60*1000,max:100,message:{error:'Túl sok kérés érkezett, próbáld újra később.'}});
const corsOptions={origin:'*',methods:['GET','POST','PUT','DELETE'],allowedHeaders:['Content-Type','Authorization','x-auth-token']};

app.use(limiter);
app.use(helmet());
app.use(cors(corsOptions));
app.use((req,res,next)=>{
    res.setHeader('Content-Security-Policy',"script-src 'self' https://cdn.jsdelivr.net;");
    next();
});

app.use(express.json());
app.use(express.static('../frontend'));
app.use('/api',apiRoutes);
app.use((err,req,res,next)=>{
    console.error(err.stack);
    res.status(500).send({error:'Hiba történt, kérlek próbáld újra később.'});
});

app.use(morgan('combined'));

app.listen(port,()=>console.log('\x1b[36m%s\x1b[0m',`Listening on: ${port}`));