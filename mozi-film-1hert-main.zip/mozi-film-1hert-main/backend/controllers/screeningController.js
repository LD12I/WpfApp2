// screeningController.js
const Joi = require('joi');
const { Op } = require('sequelize');
// A modelleket az index fájlból importáljuk
const { Screenings, User, Movies } = require('../models');
const { Booking } = require('../models');

exports.getAllScreenings = async (req, res) => {
    try {
        const screenings = await Screenings.findAll({
            include: [{
                model: Movies,
                attributes: ['title']
            }],
            order: [['time', 'ASC']]
        });
        res.status(200).json(screenings);
    } catch (error) {
        console.error('Error fetching screenings:', error);
        res.status(500).json({ message: 'Error fetching Screenings' });
    }
}

exports.getScreeningsByMovieId = async (req, res) => {
    const { movieId } = req.params;
    try {
        const screenings = await Screenings.findAll({
            where: { movieId: movieId },
            include: [{
                model: Movies,
                attributes: ['title']
            }],
            order: [['time', 'ASC']]
        });
        res.status(200).json(screenings);
    } catch (error) {
        console.error(`Error fetching screenings for movie ID ${movieId}:`, error);
        res.status(500).json({ message: 'Error fetching screenings by movie' });
    }
};

exports.getScreeningsByDate = async (req, res) => {
    const { date } = req.params;
    try {
        const startDate = new Date(`${date}T00:00:00.000Z`);
        const endDate = new Date(`${date}T23:59:59.999Z`);
        if (isNaN(startDate.getTime())) {
            return res.status(400).json({ message: 'Érvénytelen dátum formátum. Használja az YYYY-MM-DD formátumot.' });
        }
        const screenings = await Screenings.findAll({
            where: {
                time: { [Op.between]: [startDate, endDate] }
            },
            include: [{
                model: Movies,
                attributes: ['title']
            }],
            order: [['time', 'ASC']]
        });
        res.status(200).json(screenings);
    } catch (error) {
        console.error(`Error fetching screenings for date ${date}:`, error);
        res.status(500).json({ message: 'Error fetching screenings by date' });
    }
};

exports.getOneScreeningByID = async (req, res) => {
    const { id } = req.params;
    try {
        const screening = await Screenings.findByPk(id, {
            include: [{ model: Movies }]
        });
        if (!screening) {
            return res.status(404).json({ message: 'Screening not found' });
        }
        res.status(200).json(screening);
    } catch (error) {
        console.error(`Error fetching screening with ID ${id}:`, error);
        res.status(500).json({ message: 'Error fetching screening by ID' });
    }
};

exports.createScreening = async (req, res) => {
    const { room, time, movieId, accountId } = req.body;
    try {
        const schema = Joi.object({
            movieId: Joi.number().integer().required(),
            room: Joi.string().min(1).max(100).required(),
            time: Joi.date().iso().required(),
            accountId: Joi.number().integer().required()
        });
        const { error } = schema.validate({ movieId, room, time, accountId });
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        const user = await User.findByPk(accountId);
        if (!user) {
            return res.status(404).json({ message: 'Felhasználó nem található' });
        }
        if (user.isAdmin !== true) {
            return res.status(403).json({ message: 'Csak adminisztrátor hozhat létre vetítéseket' });
        }
        const movieExists = await Movies.findByPk(movieId);
        if (!movieExists) {
            return res.status(404).json({ message: 'A megadott film nem található' });
        }
        const newScreening = await Screenings.create({
            movieId,
            room,
            time: time,
            adminName: user.username
        });
        res.status(201).json(newScreening);
    } catch (error) {
        console.error('Hiba a vetítés létrehozásakor:', error);
        res.status(500).json({ message: 'Hiba a vetítés létrehozásakor' });
    }
}



exports.getScreeningStats = async (req, res) => {
    const screeningId = req.params.id;

    try {
        const screening = await Screenings.findByPk(screeningId);
        if (!screening) {
            return res.status(404).json({ message: 'A vetítés nem található.' });
        }

        const totalSeats = screening.totalSeats || 100; // vagy valós mező ha van
        const bookingCount = await Booking.count({ where: { screeningId } });

        const percentage = ((bookingCount / totalSeats) * 100).toFixed(1);

        res.json({
            screeningId,
            totalSeats,
            bookingCount,
            percentage: Number(percentage)
        });
    } catch (error) {
        console.error('Hiba a vetítés statisztikájánál:', error);
        res.status(500).json({ message: 'Szerverhiba' });
    }
};