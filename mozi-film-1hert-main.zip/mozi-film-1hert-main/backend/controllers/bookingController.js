// controllers/bookingController.js

const Joi = require('joi');
// A modelleket az index fájlból importáljuk
const { Booking, Screenings, Movies, User } = require('../models');

// Új foglalás létrehozása
exports.createBooking = async (req, res) => {
    const userId = req.user;
    const { screeningId, seat } = req.body;
    try {
        const schema = Joi.object({
            screeningId: Joi.number().integer().required(),
            seat: Joi.string().min(1).max(50).required().trim()
        });
        const { error } = schema.validate({ screeningId, seat });
        if (error) {
            return res.status(400).json({ message: error.details[0].message });
        }
        const screeningExists = await Screenings.findByPk(screeningId);
        if (!screeningExists) {
            return res.status(404).json({ message: 'A megadott vetítés nem található.' });
        }
        const seatTaken = await Booking.findOne({ where: { screeningId, seat } });
        if (seatTaken) {
            return res.status(409).json({ message: 'Ez a hely már foglalt ezen a vetítésen.' });
        }
        const newBooking = await Booking.create({
            userId,
            screeningId,
            seat
        });
        res.status(201).json(newBooking);
    } catch (error) {
        console.error('Hiba a foglalás létrehozásakor:', error);
        res.status(500).json({ message: 'Szerverhiba történt a foglalás során.' });
    }
};

// A bejelentkezett felhasználó foglalásainak lekérdezése
exports.getUserBookings = async (req, res) => {
    const userId = req.user;
    try {
        const bookings = await Booking.findAll({
            where: { userId },
            include: [{
                model: Screenings,
                attributes: ['id', 'time', 'room'],
                include: [{
                    model: Movies,
                    attributes: ['title', 'img']
                }]
            }],
            order: [ ['createdAt', 'DESC'] ]
        });
        res.status(200).json(bookings);
    } catch (error) {
        console.error('Hiba a foglalások lekérdezésekor:', error);
        res.status(500).json({ message: 'Szerverhiba történt a foglalások lekérdezésekor.' });
    }
};

// Foglalás törlése
exports.deleteBooking = async (req, res) => {
    const userId = req.user;
    const { id: bookingId } = req.params;
    try {
        const booking = await Booking.findByPk(bookingId);
        if (!booking) {
            return res.status(404).json({ message: 'A foglalás nem található.' });
        }
        const user = await User.findByPk(userId);
        if (booking.userId !== userId && !user.isAdmin) {
             return res.status(403).json({ message: 'Nincs jogosultsága ennek a foglalásnak a törléséhez.' });
        }
        await booking.destroy();
        res.status(200).json({ message: 'Foglalás sikeresen törölve.' });
    } catch (error) {
        console.error('Hiba a foglalás törlésekor:', error);
        res.status(500).json({ message: 'Szerverhiba történt a foglalás törlésekor.' });
    }
};